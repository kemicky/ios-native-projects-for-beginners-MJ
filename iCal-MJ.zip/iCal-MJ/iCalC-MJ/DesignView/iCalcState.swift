//
//  iCalcState.swift
//  iCalC-MJ
//
//  Created by IACD-Air-4 on 2021/05/13.
//

import SwiftUI

struct iCalcState{
    
    var currentNumber: Double = 0
    var storedNumber:  Double?
    var storedAction: iCalcActionView.Action?
    
    
    mutating func appendNumber(_ num: Double){
        if num.truncatingRemainder(dividingBy: 1) == 0
            &&
            currentNumber.truncatingRemainder(dividingBy: 1) == 0
        {
            currentNumber = 10 * currentNumber + num
            
      }
        
            
        else{
              currentNumber = num
            
          
        }
    
        
    }//func
   



}//struct

/*
 let alert = UIAlertController(
 title: "Invalid Input",
 message: "Input exceeds 14 numbers",
 preferredStyle: .alert)
 alert.addAction(UIAlertAction(title: "Okay",style: .default))
 alert.present(alert, animated: true, completion: nil)
 */
