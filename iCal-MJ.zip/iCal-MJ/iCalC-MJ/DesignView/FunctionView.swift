//
//  FunctionView.swift
//  iCalC-MJ
//
//  Created by IACD-Air-4 on 2021/05/13.
//

import SwiftUI

struct FunctionView : View {
    
    enum MathFunction{
        case sinus,cosinus,tangents
        
        func String() -> String {
            switch self {
                case .sinus: return "sin"
                case .cosinus: return "cos"
                case .tangents: return "tan"
                
            }//switch
        }//func
        
        func operation(_ input: Double) -> Double {
       
            switch self {
                case .sinus:    return sin(input)
                case .cosinus:  return cos(input)
                case .tangents: return tan(input)
                
            }//switch
            
        }//func
        
    }//enum
    
    var function: MathFunction
    @Binding var state: iCalcState

    var body: some View{
        
        Text(function.String())
            .font(.title)
            .bold()
            .foregroundColor(.white)
            .frame(width: UIScreen.main.bounds.width/6, height: UIScreen.main.bounds.height/12)
            .background(Color("ColorFunction"))
            .cornerRadius(12.0)
            .shadow(color: Color("ColorSwan").opacity(0.2), radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/, x:0, y: 10.0)
            .onTapGesture {
                self.state.currentNumber = self.function.operation(self.state.currentNumber)
            }
        
    }//body
    
    
}//functionView
