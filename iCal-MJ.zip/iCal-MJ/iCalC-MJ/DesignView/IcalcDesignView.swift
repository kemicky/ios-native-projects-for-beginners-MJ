//
//  IcalcDesignView.swift
//  iCalC-MJ
//
//  Created by IACD-Air-4 on 2021/05/13.
//

import SwiftUI

struct IcalcDesignView: View {
    
    @State private var state = iCalcState()
    
    var displayedString: String{
        //formating π
        if state.currentNumber == .pi{
            return String(format: "%.3f", arguments: [state.currentNumber])
            
        }//if
        if Int(Double(state.currentNumber * 180 / .pi)) != 0{
            
            return String(format: "%.3f", arguments: [state.currentNumber])
            
        }//if
        
            
           return String(Int(state.currentNumber))
            
        
    }//var
    
    var body: some View {
        NavigationView{
        ZStack {
            
            Color("ColorSwan").opacity(0.5).edgesIgnoringSafeArea(.top)
            
        VStack(alignment: .center,spacing: 15){
            
        Spacer()
            VStack(alignment: .trailing,spacing: 15) {
               Text(displayedString)
                .font(.largeTitle)
                .bold()
                .foregroundColor(Color("ColorSwan"))
                .lineLimit(2)
                .padding(.vertical, 60)
                .padding(.horizontal,15)
                .animation(.spring())
              }
            .frame(width: UIScreen.main.bounds.width - 30, height: 80, alignment: .trailing)
            .background(Color("ColorBackDark").opacity(0.7))
            .shadow(color: Color("ColorSwan").opacity(0.5), radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/, x:0, y: 10.0)
            .cornerRadius(15)
            
                HStack(alignment:.center,spacing: 15){
                    iCalcActionView(action: .allClear,state: $state)
                    FunctionView(function: .sinus, state: $state)
                    FunctionView(function: .cosinus, state: $state)
                    FunctionView(function: .tangents, state: $state)
                }//HStack1
                
                HStack(alignment:.center,spacing: 15){
                    iCalcNumView(num: 1,state: $state)
                    iCalcNumView(num: 2,state: $state)
                    iCalcNumView(num: 3,state: $state)
                    iCalcActionView(action: .clear,state: $state)
                }//HStack2
                
                HStack(alignment:.center,spacing: 15){
                    iCalcNumView(num: 4,state: $state)
                    iCalcNumView(num: 5,state: $state)
                    iCalcNumView(num: 6,state: $state)
                    iCalcActionView(action: .plus,state: $state)

                }//HStack3
                
                HStack(alignment:.center,spacing: 15){
                    iCalcNumView(num: 7,state: $state)
                    iCalcNumView(num: 8,state: $state)
                    iCalcNumView(num: 9,state: $state)
                    iCalcActionView(action: .minus,state: $state)
                }//HStack4
                
                HStack(alignment:.center,spacing: 15){
                    iCalcNumView(num: .pi,state: $state)
                    iCalcNumView(num:  0,state: $state)
                    iCalcActionView(action: .divide,state: $state)
                    iCalcActionView(action: .multiply,state: $state)
                
                }//HStack5
                HStack(alignment:.center,spacing: 15){
                    iCalcActionView(action: .plusminus,state: $state)
                    iCalcActionView(action: .percentage,state: $state)
                    iCalcActionView(action: .dot,state: $state)
                    iCalcActionView(action: .equal,state: $state)
            }//HStack6
                
        Spacer()
            }//VStack
            .padding(35)
            .padding(.horizontal,20)
        
        }//ZStack
        .navigationTitle(Text("iCalc"))
        .padding(.top, -30)
      }//Nav
        .edgesIgnoringSafeArea(.all)
        .padding(.top,-50)
    }//body
}//struct

struct IcalcDesignView_Previews: PreviewProvider {
    static var previews: some View {
        IcalcDesignView()
            .previewLayout(.sizeThatFits)
            .previewDisplayName("iCalcDesignView")
    }
}


/**
 let num: Double
 
 var numString: String{
 //showing the pi sign
 if num  == .pi{
 
 return "π"
 
 }//
 
 return String(Int(num))
 }//var
 
 */
