//
//  iCalcNumView.swift
//  iCalC-MJ
//
//  Created by IACD-Air-4 on 2021/05/13.
//

import SwiftUI

struct iCalcNumView: View {
    
    let num: Double
    @Binding var state: iCalcState
    let pi = Double.pi
    
    //function
    var numString: String{
        //showing the pi sign
        if num  == .pi{
        
            
            return "π"
            
        }//if
        return String(Int(num))
        
    }//var
    
    
    var body: some View{
      
        Text(numString)
            .font(.title)
            .bold()
            .foregroundColor(.white)
            .frame(width: UIScreen.main.bounds.width/6, height: UIScreen.main.bounds.height/12)
            .background(Color("ColorBlueDark"))
            .cornerRadius(15.0)
            .shadow(color: Color("ColorBlueLight").opacity(0.3), radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/, x:0, y: 10.0)
            .onTapGesture {
                 self.state.appendNumber(self.num)
            }
        
    }//body
}//struct
