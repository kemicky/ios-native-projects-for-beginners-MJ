//
//  iCalcActionView.swift
//  iCalC-MJ
//
//  Created by IACD-Air-4 on 2021/05/13.
//

import SwiftUI

struct iCalcActionView : View {
    
    
    
    enum Action{
        case equal, clear, plus, minus, multiply, divide, percentage, plusminus,dot, allClear
        
        func Image() -> Image {
            switch self {
                case .equal:
                    return SwiftUI.Image(systemName: "equal")
                case .clear:
                    return SwiftUI.Image(systemName: "arrow.backward")
                case .plus:
                    return SwiftUI.Image(systemName: "plus")
                case .minus:
                    return SwiftUI.Image(systemName: "minus")
                case .multiply:
                    return SwiftUI.Image(systemName: "multiply")
                case .divide:
                    return SwiftUI.Image(systemName: "divide")
                case .percentage:
                    return SwiftUI.Image(systemName: "percent")
                case .plusminus:
                    return SwiftUI.Image(systemName: "plusminus")
                case .dot:
                    return  SwiftUI.Image(systemName: "dot.square")
                case .allClear:
                    return SwiftUI.Image(systemName: "togglepower")
            }//switch
        }//func
       
        func calculate(_ input1: Double,_ input2: Double) -> Double? {
                switch self {
                case .plus:
                return input1 + input2
                case .minus:
                return input1 - input2
                case .multiply:
                return input1 * input2
                case .divide:
                return input1 / input2
                case .percentage:
                    return input1 / input2 * 0.01
                default:
                return nil
        
        }//switch

    }//func
        
}//enum


var action: Action
@Binding var state: iCalcState

var body: some View{
    
    Text(action.Image())
        .font(.title)
        .fontWeight(.semibold)
        .foregroundColor(.white)
        .frame(width: UIScreen.main.bounds.width/6, height: UIScreen.main.bounds.height/12)
        .background(Color("ColorAction"))
        .cornerRadius(15.0)
        .shadow(color: Color("ColorFunction").opacity(0.3), radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/, x:0, y: 10.0)
        .onTapGesture {
            self.tapped()
        }//onTappedGesture
}//body

private func tapped(){
    switch action {
        case .clear:
            state.currentNumber = 0
            state.storedNumber = nil
            state.storedNumber = nil
            break
        case .dot:
            state.currentNumber = (Double(String(".")) ?? 0)
            break
        case .percentage:
            state.currentNumber = state.currentNumber * 0.01
            break
            
        case .allClear:
            state.currentNumber = 0
            state.storedNumber =  nil
            state.storedAction =  nil
            break
            
        case .equal:
            guard let storedAction = state.storedAction  else{
                return
            }
            guard let storedNumber = state.storedNumber  else{
                return
            }
            guard let result = storedAction.calculate(storedNumber, state.currentNumber) else
            {
                return
            }
            
            state.currentNumber = result
            state.storedNumber =  nil
            state.storedAction =  nil
            break
            
        default:
            state.storedNumber = state.currentNumber
            state.currentNumber =  0
            state.storedAction =  action
            break
            
    }//switch
    
    
    
    
}//func-tapped

}//struct
