//
//  iCalC_MJApp.swift
//  iCalC-MJ
//
//  Created by IACD-Air-4 on 2021/05/13.
//

import SwiftUI
import UIKit

@main
struct iCalC_MJApp: App {
    
    init(backgroundColor: UIColor?) {
    UINavigationBar.appearance().sizeThatFits(CGSize(width: UIScreen.main.bounds.size.width, height: 70.0))
    
    }
        //Changing the Appearnce of the NavigationView globally
    init(){UINavigationBar.appearance().largeTitleTextAttributes = [.foregroundColor: UIColor.init(Color("ColorBackDark").opacity(0.7))]
        UINavigationBar.appearance().largeTitleTextAttributes = [.font : UIFont(name: "Georgia", size: 20)!] //Use this if NavigationBarTitle is with Large Font
        
    }
    
    var body: some Scene {
        WindowGroup {
            iCalcView()
        }
    }
}
