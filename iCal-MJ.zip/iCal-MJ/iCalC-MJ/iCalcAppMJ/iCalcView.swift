//
//  iCalcView.swift
//  iCalC-MJ
//
//  Created by IACD-Air-4 on 2021/05/13.
//

import SwiftUI

struct iCalcView: View {
    var body: some View {
      
        IcalcDesignView()
    }//body
}//struct

struct iCalcView_Previews: PreviewProvider {
    static var previews: some View {
        iCalcView()
    }
}
