// App developed by Oluwakemi Mary Jones

import SwiftUI

struct GameOnboarding: View {
    @State var showSplash = true
   

    var body: some View {
        
        ZStack{
         
            Group{
               
                Game()
                    .edgesIgnoringSafeArea(.all)
                
                SplashScreen()
                    .padding(.top, 25)
                    .opacity(showSplash ? 1 : 0)
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                            SplashScreen.shouldAnimate = false
                            withAnimation() {
                                self.showSplash = false
                
                            }//withanimation
                        }//dispatchqueue
                        
                    }//onappear
                    
               
                
                
            }//group
                
        
            
        }//ZStack
        .accentColor(Color(.label))
        
    }//body
    
   
   
}//Struct

#if DEBUG
struct GameOnboarding_Previews: PreviewProvider {
    static var previews: some View {
        GameOnboarding()
            .previewLayout(.sizeThatFits)
            .previewDisplayName("GameOnboarding")
    }
}
#endif
