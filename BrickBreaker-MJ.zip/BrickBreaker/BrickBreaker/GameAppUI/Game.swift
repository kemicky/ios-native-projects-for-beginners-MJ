// App developed by Oluwakemi Mary Jones

import SwiftUI
import SpriteKit

struct Game: View {
    @AppStorage("highestScore") var highestScore = 0
    @StateObject private var gameScene = GameScene()
    
    
    var body: some View {
        ZStack{
            GradientColor()
            SpriteView(scene: gameScene)
                
            VStack(alignment: .leading){
            
                Text("Level: \(gameScene.level)")
                    .font((.system(size: 20, weight: .heavy, design: .rounded)))
                    .foregroundColor(.accentColor)
                    .padding(.top,UIApplication.shared.windows.filter{$0.isKeyWindow}.first?.safeAreaInsets.top)
                     .padding(.leading, 15)
                
                Text("Score: \(gameScene.score)")
                    .font((.system(size: 22, weight: .heavy, design: .rounded)))
                    .foregroundColor(.accentColor)
                    .padding(.leading)
                    
                
            Spacer()
                
            }//VStack
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 10)
            
            //if else - check for validation.
          
            if gameScene.isGameOver{
                VStack{
                    Text("Game Over")
                        .font((.system(size: 35, weight: .heavy, design: .rounded)))
                        .foregroundColor(.accentColor)
                        .padding(.leading)
                        .padding()
                    
                    if gameScene.score > highestScore{
                        HStack {
                            Text("Highest Score: ")
                                .font((.system(size: 25, weight: .heavy, design: .rounded)))
                                .foregroundColor(.accentColor)
                                .padding(.leading)
                                
                     
                            Text("\(gameScene.score)")
                                .font((.system(size: 25, weight: .heavy, design: .rounded)))
                                .foregroundColor(.accentColor)
                                .padding(.leading)
                        }//HStack
                        .frame(width: UIScreen.main.bounds.width - 30)
                        .padding(.horizontal)
               
                    }//if-2
                    Text("Play Again")
                        .font((.system(size: 26, weight: .heavy, design: .rounded)))
                        .foregroundColor(.accentColor)
                        .padding(.leading)
                        .padding()
                        .onTapGesture {
                            if gameScene.score > highestScore{
                                
                                highestScore = gameScene.score
                            }
                            gameScene.isGameOver.toggle()
                            gameScene.makeBall()
                            gameScene.makeBricks()
                            gameScene.score = 0
                        }
                    
                }//VStack
                
            }//if-1
        
            
        }//ZStack
        .ignoresSafeArea()
        .accentColor(Color(.label))
        
    }//body
}//struct


#if DEBUG
struct GameView_Previews: PreviewProvider {
    static var previews: some View {
        Game()
            .previewLayout(.sizeThatFits)
            .previewDisplayName("Game")
    }
}
#endif


/*
 .padding(.top,UIApplication.shared.windows.filter{$0.isKeyWindow}.first?.safeAreaInsets.top)
 
 
 */
