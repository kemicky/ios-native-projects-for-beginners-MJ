//
//  Footer.swift
//  BrickBreaker
//
//  Created by IACD-Air-4 on 2021/06/01.
//

import SwiftUI

struct Footer: View {
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 5)
                .fill(LinearGradient(gradient: Gradient(colors: [Color(#colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)), Color(#colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1))]), startPoint: .topLeading, endPoint: .bottomTrailing)).opacity(0.5)
                .clipShape(RoundedRectangle(cornerRadius: 5))
                .padding(.horizontal,0)
                .shadow(color: Color.white, radius: 3, x: 3, y: 3)
            
            VStack {
                
                HStack {
                    
                    Text("Dev by: KemyMJ")
                        .font(.footnote)
                        .bold()
                        .foregroundColor(.black)
                        .padding(5)
                        
                    Spacer()
                    Image(systemName: "gamecontroller.fill")
                        .imageScale(.large)
                    Image("ballie")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 40, height: 50)
                        .padding(1)
                    Spacer()
                    
                    Text("© MJ Konceptz 2021, IACD")
                    .font(.footnote)
                    .bold()
                    .foregroundColor(.black)
                    .padding(5)
                    
                }//HStack
                .padding()
                
            }//Vstack
            
        }//ZStack
        .accentColor(Color(.label))
    }//var-body
}//struct

struct Footer_Previews: PreviewProvider {
    static var previews: some View {
        Footer()
            .previewLayout(.fixed(width: 600, height: 50))
            .previewDisplayName("Footer")
    }
}


/*
RoundedRectangle(cornerRadius: 5)
    .fill(LinearGradient(gradient: Gradient(colors: [Color.white, Color.blue]), startPoint: .topLeading, endPoint: .bottomTrailing)).opacity(0.5)
    .clipShape(RoundedRectangle(cornerRadius: 10))
    .padding(.horizontal,1)
    .shadow(color: Color.white, radius: 3, x: 3, y: 3)

 */
