//
//  ColorText.swift
//  BrickBreaker
//
//  Created by IACD-Air-4 on 2021/06/07.
//

import SwiftUI

struct ColorText: View {
    var body: some View {
        LinearGradient(gradient: Gradient(colors: [
            Color(#colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)),
            Color(#colorLiteral(red: 0.2588235438, green: 0.7568627596, blue: 0.9686274529, alpha: 1)),
            Color(#colorLiteral(red: 0.8161608509, green: 0.8161608509, blue: 0.8161608509, alpha: 1)),
            
            
            
        ]
        ), startPoint: .top,endPoint: .bottom)
        .ignoresSafeArea()
    }//body
}

struct ColorText_Previews: PreviewProvider {
    static var previews: some View {
        ColorText()
    }
}
