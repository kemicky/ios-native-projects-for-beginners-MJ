// App developed by Oluwakemi Mary Jones

import SwiftUI

struct LaunchScreen: View {
    
    var body: some View {
        Group{
            ZStack{
              
                    withAnimation{
                        
                        Image("LaunchScreen")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 300, height: 200, alignment: .center)
                            .padding()
                        
                    }//animation
                    
                 
            }//ZStack
            .accentColor(Color(.label))
            
        }//group
    }//body
}//struct

struct LaunchScreen_Previews: PreviewProvider {
    static var previews: some View {
        LaunchScreen()
            .previewDisplayName("LaunchScreen")
    }//var-prev
}//struct-prev

