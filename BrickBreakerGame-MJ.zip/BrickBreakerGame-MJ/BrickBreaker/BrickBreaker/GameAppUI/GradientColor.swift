
import SwiftUI

struct GradientColor: View {
    var body: some View {
        LinearGradient(gradient: Gradient(colors: [
            Color(#colorLiteral(red: 1, green: 0.5212053061, blue: 1, alpha: 1)),
            Color(#colorLiteral(red: 1, green: 0.2527923882, blue: 1, alpha: 1)),
            Color(#colorLiteral(red: 1, green: 0.5212053061, blue: 1, alpha: 1)),
            
            
            
        ]
        ), startPoint: .top,endPoint: .bottom)
        .ignoresSafeArea()
    }//body
    
    
}//struct

struct GradientColor_Previews: PreviewProvider {
    static var previews: some View {
        GradientColor()
    }
}
