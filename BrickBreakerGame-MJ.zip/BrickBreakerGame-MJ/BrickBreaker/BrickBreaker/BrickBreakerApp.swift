

import SwiftUI

@main
struct BrickBreakerApp: App {
    var body: some Scene {
        WindowGroup {
            
            GameOnboarding()
            
        }//window
    }//body
}//struct


